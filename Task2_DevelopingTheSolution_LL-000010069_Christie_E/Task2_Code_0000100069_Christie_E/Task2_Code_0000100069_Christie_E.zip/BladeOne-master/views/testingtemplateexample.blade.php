@extends('app')



@section('content')

<h1> This is some content in between the navigation bar and footer </h1>

@endsection