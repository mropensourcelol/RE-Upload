<?php


// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	//header('Location: index.html');
	exit;
}


?>

@extends('app')

@section('content')

<div class="container">
    <div class="main-body">
		<div class="padding">
          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="UserImage" class="rounded-circle" width="150">
                    <div class="mt-3">
                      <h4><?=$_SESSION['name']?></h4>
                      <p class="text-secondary mb-1">GibJohn Tutoring Learner</p>
                      <a class="btn btn-info " target="__blank" href="learnerdashboard.php">Go To your Learner Dasahboard</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                        <h1>Maths - Unit A3</h1>
                        Understanding Credit
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/fCoKZqoHOAc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                          Wages are paid by an employer to their staff in return for work. Wages are usually paid weekly or monthly. They are either calculated on a rate of pay per hour or as an annual salary.

                        In Britain, people should be paid at least the minimum wage rate set by the government. The value of the minimum age varies depending on whether the person working is an apprentice, under the age of 18, or an adult.

                        If a person earns £5.52 and works 10 hours per week, they would earn £55.20.
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
</div>
</div>



@endsection