@extends('app')


@section('content')


<div class="alert alert-danger" role="alert">
  <h4 class="alert-heading">Unfortuntely an error has occoured, please try again! </h4>
  <p>We apologise for the inconvinience but we could not find your user details in the system!</p>
  <hr>
  <p class="mb-0">Whenever you need to, be sure to use margin utilities to keep things nice and tidy.</p>
</div>

@endsection