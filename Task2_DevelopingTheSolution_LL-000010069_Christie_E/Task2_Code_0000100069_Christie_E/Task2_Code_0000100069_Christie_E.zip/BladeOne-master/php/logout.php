<?php

session_destroy();

header('Location: /Projects/Blade-test/test_BladeOne/BladeOne/test.php');


?>