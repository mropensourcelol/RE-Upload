<?php header("Content-type: text/css"); ?>

<?php
    header("Content-type: text/css; charset: UTF-8");

    $testint = "4%";
?>
