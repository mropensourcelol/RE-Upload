<?php

include_once 'lib/setup-blade.php';
include 'Models/db.php';